import React from "react"
import "./Spinner.css"

const Spinner = props => (
   <div style={{ textAlign: "center" }}>
      <div className="Loader" />
   </div>
)

export default Spinner
